/*
 *           __                          __ 
*      _____/ /____  ______  ____  _____/ /_
 *    / ___/ //_/ / / / __ \/ __ \/ ___/ __/
 *   (__  ) ,< / /_/ / /_/ / /_/ / /  / /_  
 *  /____/_/|_|\__, / .___/\____/_/   \__/  
 *           /____/_/                  
 *              
 *  Skyport Panel v1.0.0 (Combined Version)
 *  (c) 2024 Matt James and contributors
 * 
*/

/**
 * @fileoverview Main server file for Skyport Panel. Sets up the express application,
 * configures middleware for sessions, body parsing, and websocket enhancements, and dynamically loads route
 * modules. This file also sets up the server to listen on a configured port and initializes logging.
 */

const express = require('express');
const session = require('express-session');
const passport = require('passport');
const bodyParser = require('body-parser');
const CatLoggr = require('cat-loggr');
const fs = require('node:fs');
const config = require('./config.json');
const ascii = fs.readFileSync('./handlers/ascii.txt', 'utf8');
const app = express();
const chalk = require('chalk');
const expressWs = require('express-ws')(app);
const path = require('path');
const { db } = require('./handlers/db.js');
const translationMiddleware = require('./handlers/translation');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const theme = require('./storage/theme.json');
const analytics = require('./utils/analytics.js');
const sqlite = require("better-sqlite3");
const SqliteStore = require("better-sqlite3-session-store")(session);
const sqliteSession = new sqlite("sessions.db");
const { loadPlugins } = require('./plugins/loadPls.js');
let plugins = loadPlugins(path.join(__dirname, './plugins'));
plugins = Object.values(plugins).map(plugin => plugin.config);

const { init } = require('./handlers/init.js');
const log = new CatLoggr();

// Session management with SQLite store
app.use(session({
  store: new SqliteStore({
    client: sqliteSession,
    expired: { clear: true, intervalMs: 9000000 }
  }),
  secret: config.session_secret || "secret",
  resave: true,
  saveUninitialized: true
}));

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(analytics);
app.use(translationMiddleware);
app.use(passport.initialize());
app.use(passport.session());

// Rate limiting for POST requests
const postRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 6,
  message: 'Too many requests, please try again later'
});

app.use((req, res, next) => {
  if (req.method === 'POST') {
    postRateLimiter(req, res, next);
  } else {
    next();
  }
});

// Set language handler
function getLanguages() {
  return fs.readdirSync(__dirname + '/lang').map(file => file.split('.')[0]);
}

app.get('/setLanguage', async (req, res) => {
  const lang = req.query.lang;
  if (lang && getLanguages().includes(lang)) {
    res.cookie('lang', lang, { maxAge: 90000000, httpOnly: true, sameSite: 'strict' });
    req.user.lang = lang;
    res.json({ success: true });
  } else {
    res.json({ success: false });
  }
});

// Settings Middleware
app.use(async (req, res, next) => {
  try {
    const settings = await db.get('settings');
    res.locals.languages = getLanguages();
    res.locals.ogTitle = config.ogTitle;
    res.locals.ogDescription = config.ogDescription;
    res.locals.footer = settings.footer;
    res.locals.theme = theme;
    res.locals.name = settings.name;
    res.locals.logo = settings.logo;
    res.locals.plugins = plugins;
    next();
  } catch (error) {
    log.error('Error fetching settings:', error);
    next(error);
  }
});

// Static files and caching
if (config.mode === 'production' || false) {
  app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '5');
    next();
  });

  app.use('/assets', (req, res, next) => {
    res.setHeader('Cache-Control', 'public, max-age=1');
    next();
  });
}

app.use(express.static('public'));

// Load routes dynamically
const routesDir = path.join(__dirname, 'routes');
function loadRoutes(directory) {
  fs.readdirSync(directory).forEach(file => {
    const fullPath = path.join(directory, file);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      loadRoutes(fullPath);
    } else if (stat.isFile() && path.extname(file) === '.js') {
      const route = require(fullPath);
      expressWs.applyTo(route);
      app.use("/", route);
    }
  });
}

loadRoutes(routesDir);

// Load plugin routes and views
const pluginRoutes = require('./plugins/pluginManager.js');
app.use("/", pluginRoutes);
const pluginDir = path.join(__dirname, 'plugins');
const PluginViewsDir = fs.readdirSync(pluginDir).map(addonName => path.join(pluginDir, addonName, 'views'));
app.set('views', [path.join(__dirname, 'views'), ...PluginViewsDir]);

// Initialize
init();

// Log ASCII and version
console.log(chalk.gray(ascii) + chalk.white(`version v${config.version}\n`));

// Listen on configured port
app.listen(config.port, () => log.info(`Skyport is listening on port ${config.port}`));

// 404 handler
app.get('*', async function(req, res) {
  res.render('errors/404', {
    req,
    name: await db.get('name') || 'Skyport'
  });
});